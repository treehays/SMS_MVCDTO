﻿namespace SMS_MVCDTO.Interfaces.Services
{
    public interface IAddressService
    {
    }
}

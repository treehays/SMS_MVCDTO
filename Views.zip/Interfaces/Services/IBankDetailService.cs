﻿namespace SMS_MVCDTO.Interfaces.Services
{
    public interface IBankDetailService
    {
    }
}

﻿/*using System.Web.Mvc;

namespace SMS_MVCDTO.Context
{
    public class HideTextAttribute : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
*//*            context.HttpContext.Items["HideText"] = true;*//*
        }
        public void OnActionExecuting(ActionExecutingContext context)
        {
        }

    }
}*/

﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SMSMVCDTO.Migrations
{
    /// <inheritdoc />
    public partial class TestingAddedsuperandsale : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

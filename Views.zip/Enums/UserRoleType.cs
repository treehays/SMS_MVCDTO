﻿namespace SMS_MVCDTO.Enums
{
    public enum UserRoleType
    {
        //SuperAdmin = 1,
        //SalesManager,
        //Attendant,
        //Customer,
        //StockKeeper
    }
}

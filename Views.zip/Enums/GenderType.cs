﻿namespace SMS_MVCDTO.Enums
{
    public enum GenderType
    {
        Male = 1,
        Female
    }
}

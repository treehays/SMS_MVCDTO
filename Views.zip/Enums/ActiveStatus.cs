﻿namespace SMS_MVCDTO.Enums
{
    public enum ActiveStatus
    {
        //tobe used later
        Active,
        notActive,
        Suspended
    }
}

﻿namespace SMS_MVCDTO.Enums
{
    public enum DeleteStatus
    {
        isDeleted,
        notDeleted
    }
}

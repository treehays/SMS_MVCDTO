﻿namespace SMS_MVCDTO.Enums
{
    public enum BankName
    {
        Access = 1,
        Citibank,
        Ecobank,
        Fidelity,
        FirstBank,
        FCMB,
        Globus,
        GTB,
        Heritage,
        Keystone,
        Optimus,
        Parallex,
        Polaris,
        Premium,
        Providus,
        Signature,
        StanbicIBTC,
        StandardChartered,
        Sterling,
        SunTrust,
        TitanTrust,
        UnionBank,
        UnitedBank,
        UnityBank,
        WemaBank,
        ZenithBank,

    }
}

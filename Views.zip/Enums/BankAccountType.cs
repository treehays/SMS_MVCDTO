﻿namespace SMS_MVCDTO.Enums
{
    public enum BankAccountType
    {
        Savings = 1,
        Current,
        Salary,
    }
}

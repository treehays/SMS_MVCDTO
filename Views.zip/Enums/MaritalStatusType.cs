﻿namespace SMS_MVCDTO.Enums
{
    public enum MaritalStatusType
    {
        Single = 1,
        Married,
        Divorced,
        Widowed
    }
}

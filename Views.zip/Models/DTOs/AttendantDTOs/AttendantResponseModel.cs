﻿namespace SMS_MVCDTO.Models.DTOs.AttendantDTOs
{
    public class AttendantResponseModel : BaseResponse
    {
        public AttendantDTOs Data { get; set; }
    }
}

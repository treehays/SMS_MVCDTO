﻿namespace SMS_MVCDTO.Models.DTOs.AttendantDTOs
{
    public class UpdateAttendantPasswordRequestModel
    {
        public string StaffId { get; set; }
        public string Password { get; set; }
    }

}

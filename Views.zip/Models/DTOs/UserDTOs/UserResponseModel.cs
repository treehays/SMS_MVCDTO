﻿namespace SMS_MVCDTO.Models.DTOs.UserDTOs
{
    public class UserResponseModel : BaseResponse
    {
        public UserDTOs Data { get; set; }
    }
}

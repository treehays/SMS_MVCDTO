﻿using SMS_MVCDTO.Enums;

namespace SMS_MVCDTO.Models.DTOs.UserDTOs
{
    public class UpdateUserRoleRequestModel
    {
        public int RoleId { get; set; }
        public string StaffId { get; set; }
        //public string FirstName { get; set; }
        //public string LastName { get; set; }

    }
}

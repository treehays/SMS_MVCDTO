﻿namespace SMS_MVCDTO.Models.DTOs.TransactionDTOs
{
    public class TransactionResponseModel : BaseResponse
    {
        public TransactionDTOs Data { get; set; }
    }
}

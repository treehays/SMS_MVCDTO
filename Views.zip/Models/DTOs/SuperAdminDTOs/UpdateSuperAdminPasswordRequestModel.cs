﻿namespace SMS_MVCDTO.Models.DTOs.SuperAdminDTOs
{
    public class UpdateSuperAdminPasswordRequestModel
    {
        public string Pin { get; set; }
    }

}

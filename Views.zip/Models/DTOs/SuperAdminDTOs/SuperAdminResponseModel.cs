﻿namespace SMS_MVCDTO.Models.DTOs.SuperAdminDTOs
{
    public class SuperAdminResponseModel : BaseResponse
    {
        public SuperAdminDTOs Data { get; set; }
    }

}

﻿namespace SMS_MVCDTO.Models.DTOs.SalesManagerDTOs
{
    public class SalesManagerResponseModel : BaseResponse
    {
        public SalesManagerDTOs Data { get; set; }
    }

    //public class LoginRequestModel
    //{
    //    [Required]
    //    public string StaffId { get; set; }
    //    [Required]
    //    public string Password { get; set; }
    //}
}

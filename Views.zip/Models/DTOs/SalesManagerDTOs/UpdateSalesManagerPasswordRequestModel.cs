﻿//namespace SMS_MVCDTO.DTOs.SalesManagerDTOs
//{
//    public class UpdateSalesManagerPasswordRequestModel
//    {
//        public string Pin { get; set; }
//    }

//public class LoginRequestModel
//{
//    [Required]
//    public string StaffId { get; set; }
//    [Required]
//    public string Password { get; set; }
//}
//}

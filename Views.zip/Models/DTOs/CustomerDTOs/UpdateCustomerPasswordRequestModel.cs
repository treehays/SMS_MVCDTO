﻿namespace SMS_MVCDTO.Models.DTOs.CustomerDTOs
{
    public class UpdateCustomerPasswordRequestModel
    {
        public string StaffId { get; set; }
        public string Password { get; set; }
    }

    //public class LoginRequestModel
    //{
    //    [Required]
    //    [Required]
    //    public string Password { get; set; }
    //}
}

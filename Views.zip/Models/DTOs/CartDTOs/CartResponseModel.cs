﻿namespace SMS_MVCDTO.Models.DTOs.CartDTOs
{
    public class CartResponseModel : BaseResponse
    {
        public CartDTO Data { get; set; }
    }
}

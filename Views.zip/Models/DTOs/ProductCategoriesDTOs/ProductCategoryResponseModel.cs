﻿namespace SMS_MVCDTO.Models.DTOs.ProductCategoriesDTOs
{
    public class ProductCategoryResponseModel : BaseResponse
    {
        public ProductCategoryDTOs Data { get; set; }
    }
}

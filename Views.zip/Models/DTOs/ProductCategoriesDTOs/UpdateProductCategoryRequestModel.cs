﻿namespace SMS_MVCDTO.Models.DTOs.ProductCategoriesDTOs
{
    public class UpdateProductCategoryRequestModel
    {
        public string CategoryCode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}

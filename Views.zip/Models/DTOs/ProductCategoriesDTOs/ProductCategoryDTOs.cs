﻿namespace SMS_MVCDTO.Models.DTOs.ProductCategoriesDTOs
{
    public class ProductCategoryDTOs
    {
        public int CategoryCode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
    }
}

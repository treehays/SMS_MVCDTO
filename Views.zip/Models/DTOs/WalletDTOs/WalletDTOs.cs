﻿namespace SMS_MVCDTO.Models.DTOs.WalletDTOs
{
    public class WalletDTOs
    {
        public double Debit { get; set; }
        public double Credit { get; set; }
        public double Balance { get; set; }
        public string CustomerId { get; set; }
    }

}

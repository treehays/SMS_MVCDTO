﻿namespace SMS_MVCDTO.Models.DTOs.WalletDTOs
{
    public class DebitWalletRequestModel
    {
        public double Debit { get; set; }
        public string CustomerId { get; set; }
        //public double Credit { get; set; }
    }

}

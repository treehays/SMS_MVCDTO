﻿namespace SMS_MVCDTO.Models.Entities
{
    public class BankName : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}

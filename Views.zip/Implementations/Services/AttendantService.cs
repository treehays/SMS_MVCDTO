﻿using SMS_MVCDTO.Enums;
using SMS_MVCDTO.Interfaces.Repositories;
using SMS_MVCDTO.Interfaces.Services;
using SMS_MVCDTO.Models.DTOs.AttendantDTOs;
using SMS_MVCDTO.Models.Entities;

namespace SMS_MVCDTO.Implementations.Service
{
    public class AttendantService : IAttendantService
    {
        private readonly IAttendantRepository _attendantRepository;
        private readonly IUserRepository _userRepository;
        public AttendantService(IAttendantRepository attendantRepository, IUserRepository userRepository)
        {
            _attendantRepository = attendantRepository;
            _userRepository = userRepository;
        }

        //Done

        public CreateAttendantRequestModel Create(CreateAttendantRequestModel attendant)
        {
            var sid = User.GenerateRandomId("T");
            var user = new User
            {
                StaffId = sid,
                Password = attendant.Password,
                RoleId = 3,
                Created = DateTime.Now,
                ProfilePicture = attendant.ProfilePicture,
                Email = attendant.Email,
                PhoneNumber = attendant.PhoneNumber,
                IsActive = true,

                //FirstName = attendant.FirstName,
                //LastName = attendant.LastName,

            };
            _userRepository.Create(user);

            var attend = new Attendant
            {
                FirstName = attendant.FirstName,
                LastName = attendant.LastName,
                DateOfBirth = attendant.DateOfBirth,
                Gender = attendant.Gender,
                GuarantorName = attendant.GuarantorName,
                GuarantorPhoneNumber = attendant.GuarantorPhoneNumber,
                Created = DateTime.Now,
                MaritalStatus = attendant.MaritalStatus,
                CVPath = attendant.CVPath,
            };
            _attendantRepository.Create(attend);

            return attendant;
        }

        public void Delete(int id)
        {
            var attendant = _attendantRepository.GetById(id);
            if (attendant != null)
            {
                attendant.IsDeleted = true;
                _attendantRepository.Delete(attendant);
            }

        }

        public IEnumerable<AttendantResponseModel> GetAttendants()
        {
            var attendants = _attendantRepository.GetAttendants();
            if (attendants == null)
            {
                return null;
            }
            var attendantResponseModels = attendants.Select(attendant => new AttendantResponseModel
            {
                Message = "Attendant retrieved Successfully",
                Status = true,
                Data = new AttendantDTOs
                {
                    BankAccountNumber = attendant.BankDetail.BankAccountNumber,
                    BankName = attendant.BankDetail.BankName,
                    GuarantorName = attendant.GuarantorName,
                    DateOfBirth = attendant.DateOfBirth,
                    Email = attendant.User.Email,
                    FirstName = attendant.FirstName,
                    Gender = attendant.Gender,
                    LastName = attendant.LastName,
                    GuarantorPhoneNumber = attendant.GuarantorPhoneNumber,
                    MaritalStatus = attendant.MaritalStatus,
                    PhoneNumber = attendant.User.PhoneNumber,
                    ResidentialAddress = $"{attendant.Address.StreetName}, {attendant.Address.City}",
                    StaffId = attendant.User.StaffId,
                    RoleName = attendant.User.Role.RoleName,
                }
            }).ToList();
            return attendantResponseModels;
        }

        public AttendantResponseModel GetByTesting(string email)
        {

            var attendant = _attendantRepository.Get(x => x.User.Email == email && !x.IsDeleted && x.User.IsActive);
            if (attendant != null)
            {

                var attendantResponseModel = new AttendantResponseModel
                {
                    Message = "Attendant retrieved Successfully",
                    Status = true,
                    Data = new AttendantDTOs
                    {
                        BankAccountNumber = attendant.BankDetail.BankAccountNumber,
                        BankName = attendant.BankDetail.BankName,
                        GuarantorName = attendant.GuarantorName,
                        DateOfBirth = attendant.DateOfBirth,
                        Email = attendant.User.Email,
                        FirstName = attendant.FirstName,
                        Gender = attendant.Gender,
                        LastName = attendant.LastName,
                        GuarantorPhoneNumber = attendant.GuarantorPhoneNumber,
                        MaritalStatus = attendant.MaritalStatus,
                        PhoneNumber = attendant.User.PhoneNumber,
                        ResidentialAddress = $"{attendant.Address.StreetName}, {attendant.Address.City}",
                        StaffId = attendant.User.StaffId,
                        RoleName = attendant.User.Role.RoleName,
                    }
                };
                return attendantResponseModel;
            }
            return null;
        }

        public AttendantResponseModel GetByEmail(string email)
        {

            var attendant = _attendantRepository.GetByEmail(email);
            if (attendant != null)
            {

                var attendantResponseModel = new AttendantResponseModel
                {
                    Message = "Attendant retrieved Successfully",
                    Status = true,
                    Data = new AttendantDTOs
                    {
                        BankAccountNumber = attendant.BankDetail.BankAccountNumber,
                        BankName = attendant.BankDetail.BankName,
                        GuarantorName = attendant.GuarantorName,
                        DateOfBirth = attendant.DateOfBirth,
                        Email = attendant.User.Email,
                        FirstName = attendant.FirstName,
                        Gender = attendant.Gender,
                        LastName = attendant.LastName,
                        GuarantorPhoneNumber = attendant.GuarantorPhoneNumber,
                        MaritalStatus = attendant.MaritalStatus,
                        PhoneNumber = attendant.User.PhoneNumber,
                        ResidentialAddress = $"{attendant.Address.StreetName}, {attendant.Address.City}",
                        StaffId = attendant.User.StaffId,
                        RoleName = attendant.User.Role.RoleName,

                    }
                };
                return attendantResponseModel;
            }
            return null;
        }

        public AttendantResponseModel GetById(int id)
        {
            var attendant = _attendantRepository.GetById(id);
            if (attendant != null)
            {
                var attendantResponseModel = new AttendantResponseModel
                {
                    Message = "Attendant retrieved Successfully",
                    Status = true,
                    Data = new AttendantDTOs
                    {
                        BankAccountNumber = attendant.BankDetail.BankAccountNumber,
                        BankName = attendant.BankDetail.BankName,
                        GuarantorName = attendant.GuarantorName,
                        DateOfBirth = attendant.DateOfBirth,
                        Email = attendant.User.Email,
                        FirstName = attendant.FirstName,
                        Gender = attendant.Gender,
                        LastName = attendant.LastName,
                        GuarantorPhoneNumber = attendant.GuarantorPhoneNumber,
                        MaritalStatus = attendant.MaritalStatus,
                        PhoneNumber = attendant.User.PhoneNumber,
                        ResidentialAddress = $"{attendant.Address.StreetName}, {attendant.Address.City}",
                        StaffId = attendant.User.StaffId,
                        RoleName = attendant.User.Role.RoleName,

                    }
                };
                return attendantResponseModel;
            }
            return null;
        }

        public IEnumerable<AttendantResponseModel> GetByName(string name)
        {
            var attendants = _attendantRepository.GetByName(name);
            if (attendants == null)
            {
                return null;
            }
            var attendantResponseModels = attendants.Select(attendant => new AttendantResponseModel
            {
                Message = "Attendant retrieved Successfully",
                Status = true,
                Data = new AttendantDTOs
                {
                    BankAccountNumber = attendant.BankDetail.BankAccountNumber,
                    BankName = attendant.BankDetail.BankName,
                    GuarantorName = attendant.GuarantorName,
                    DateOfBirth = attendant.DateOfBirth,
                    Email = attendant.User.Email,
                    FirstName = attendant.FirstName,
                    Gender = attendant.Gender,
                    LastName = attendant.LastName,
                    GuarantorPhoneNumber = attendant.GuarantorPhoneNumber,
                    MaritalStatus = attendant.MaritalStatus,
                    PhoneNumber = attendant.User.PhoneNumber,
                    ResidentialAddress = $"{attendant.Address.StreetName}, {attendant.Address.City}",
                    StaffId = attendant.User.StaffId,
                    RoleName = attendant.User.Role.RoleName,

                }
            }).ToList();
            return attendantResponseModels;
        }

        public AttendantResponseModel GetByPhoneNumber(string phoneNumber)
        {
            var attendant = _attendantRepository.GetByPhoneNumber(phoneNumber);
            var attendantResponseModel = new AttendantResponseModel
            {
                Message = "Attendant retrieved Successfully",
                Status = true,
                Data = new AttendantDTOs
                {
                    BankAccountNumber = attendant.BankDetail.BankAccountNumber,
                    BankName = attendant.BankDetail.BankName,
                    GuarantorName = attendant.GuarantorName,
                    DateOfBirth = attendant.DateOfBirth,
                    Email = attendant.User.Email,
                    FirstName = attendant.FirstName,
                    Gender = attendant.Gender,
                    LastName = attendant.LastName,
                    GuarantorPhoneNumber = attendant.GuarantorPhoneNumber,
                    MaritalStatus = attendant.MaritalStatus,
                    PhoneNumber = attendant.User.PhoneNumber,
                    ResidentialAddress = $"{attendant.Address.StreetName}, {attendant.Address.City}",
                    StaffId = attendant.User.StaffId,
                    RoleName = attendant.User.Role.RoleName,

                }

            };

            return attendantResponseModel;
        }


        public AttendantResponseModel Update(AttendantResponseModel attendant)
        {

            var user = _userRepository.GetById(attendant.Data.StaffId);
            if (user == null)
            {
                return null;
            }

            user.StaffId = attendant.Data.StaffId ?? user.StaffId;
            user.Attendant.FirstName = attendant.Data.FirstName ?? user.Attendant.FirstName;
            user.Attendant.LastName = attendant.Data.LastName ?? user.Attendant.LastName;


            var attendan = _attendantRepository.GetById(attendant.Data.Id);
            if (attendan == null)
            {
                return null;
            }

            attendan.FirstName = attendant.Data.FirstName ?? attendan.FirstName;
            attendan.LastName = attendant.Data.LastName ?? attendan.LastName;
            attendan.Address.StreetName = attendant.Data.ResidentialAddress ?? attendan.Address.StreetName;
            attendan.MaritalStatus = attendant.Data.MaritalStatus;
            attendan.BankDetail.BankName = attendant.Data.BankName ?? attendan.BankDetail.BankName;
            attendan.BankDetail.BankAccountNumber = attendant.Data.BankAccountNumber ?? attendan.BankDetail.BankAccountNumber;
            attendan.Modified = DateTime.Now;
            _attendantRepository.Update(attendan);
            return attendant;
        }

        public UpdateAttendantPasswordRequestModel UpdatePassword(UpdateAttendantPasswordRequestModel attendant)
        {
            var user = _userRepository.GetById(attendant.StaffId);
            if (user == null)
            {
                return null;
            }
            user.Password = attendant.Password ?? user.Password;
            _userRepository.Update(user);
            return attendant;
        }
    }
}

